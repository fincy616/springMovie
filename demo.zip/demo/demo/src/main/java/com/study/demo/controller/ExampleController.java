package com.study.demo.controller;

import com.study.demo.model.RequestUserDTO;
import com.study.demo.model.ResponseUserDTO;
import com.study.demo.service.UserMovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ExampleController {

    @Autowired
    UserMovieService usermovie;

    @GetMapping
    public ResponseUserDTO retrieveData(@RequestParam String abc,
                                        @RequestBody RequestUserDTO requestDto) {
        usermovie.usermoviedetail(abc, requestDto);

        return null;

    }

}
