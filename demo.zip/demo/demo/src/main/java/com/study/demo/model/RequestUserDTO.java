package com.study.demo.model;

import lombok.Data;

@Data
public class RequestUserDTO {
    private String userID;
    private String userName;
}
