package com.study.demo.model;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "details")
public class MovieEntity {

    @Id
    private String id;

    private String userID;
    private String userName;
    private String movieName;
    private String movieRating;
    private String movieActor;
}
