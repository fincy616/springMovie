package com.study.demo.repository;

import com.study.demo.model.MovieEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface MovieRepo extends MongoRepository<MovieEntity, String> {

    public Optional findByUserIDAndUserName(String userID, String userName);
}
