package com.study.demo.service;

import com.study.demo.model.RequestUserDTO;
import com.study.demo.repository.MovieRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserMovieService {

    @Autowired
    MovieRepo movieRepository;
    public RequestUserDTO usermoviedetail(String abc, RequestUserDTO requestDto){

        Optional byUserIDAndUserName = movieRepository.findByUserIDAndUserName(requestDto.getUserID(), requestDto.getUserName());

        return null;

    }
}
