package com.study.demo.model;

import lombok.Data;

@Data
public class ResponseUserDTO {
    private String movieName;
    private String movieRating;
    private String movieActor;
}
